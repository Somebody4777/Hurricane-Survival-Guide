import java.awt.*;
import hsa.Console; //import Console class
import hsa.Console;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.ImageIO;
import java.util.*;
public class imageTest
{
Console c; // c is variable representation of Console
public imageTest () //constructor
{
c= new Console(); // creates new instance of Console for use by the class
}
public void buttons(){
Color bob = new Color(100,100,100);
c.setColor(bob);
c.fillRect(20,200,200,75);
c.setFont(new Font("Courier", 1, 18));
c.setColor(Color.white);
c.drawString("Press 'p' to play", 25,240);
}
public void mainMenu()
{
try
{

// Menu Image and opitons
try
{ // imports image
while(true){
BufferedImage menuBackground = ImageIO.read (new File ("pixil-frame-0.png"));
c.drawImage (menuBackground, -190, 0, null);
buttons();
BufferedImage menuBackground2 = ImageIO.read (new File ("pixil-frame-1.png"));
c.drawImage (menuBackground2, -190, 0, null);
double num = Math.floor(Math.random()*5);
buttons();
if(num > 0.0){
BufferedImage menuBackground3 = ImageIO.read (new File ("pixil-frame-2.png"));
c.drawImage (menuBackground3, -190, 0, null);
buttons();
}
else{
BufferedImage menuBackground3 = ImageIO.read (new File ("pixil-frame-3.png"));
c.drawImage (menuBackground3, -190, 0, null);
buttons();
}
}
}
catch (IOException e)
{
}
}
catch(Exception e)
{}
}

public static void main (String [] args)
{
imageTest p= new imageTest();
p.mainMenu();
} //main method close
} // imageTest class close
