import java.awt.*;
import hsa.Console; //import Console class
import hsa.Console;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.ImageIO;
import java.util.*;
public class maze2 extends Thread

{
    Console c;
    public maze2 (Console con)
    {
	c = con;
    }


    public void background ()
    {

	try
	{

	    // Menu Image and opitons
	    try
	    { // imports image
		for (int i = 0 ; i <= 1 ; i++)
		{
		    BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
		    c.drawImage (menuBackground, 0, 0, null);
		}
	    }
	    catch (IOException e)
	    {
	    }

	}
	catch (Exception e)
	{
	}
	notes ();
    }


    public void notes ()
    {
	try
	{
	    BufferedImage note = ImageIO.read (new File ("frame-1-removebg-preview.png"));
	    c.drawImage (note, 0, 0, null);

	}

	catch (IOException e)
	{
	}
	try
	{
	    BufferedImage note = ImageIO.read (new File ("frame-1-removebg-preview.png"));
	    c.drawImage (note, 250, 100, null);

	}

	catch (IOException e)
	{
	}
	try
	{
	    BufferedImage note = ImageIO.read (new File ("frame-1-removebg-preview.png"));
	    c.drawImage (note, 310, 0, null);

	}

	catch (IOException e)
	{
	}
	try
	{
	    BufferedImage note = ImageIO.read (new File ("frame-1-removebg-preview.png"));
	    c.drawImage (note, 400, 0, null);

	}

	catch (IOException e)
	{
	}
	try
	{
	    BufferedImage note = ImageIO.read (new File ("frame-1-removebg-preview.png"));
	    c.drawImage (note, 250, 230, null);

	}

	catch (IOException e)
	{
	}
	try
	{
	    BufferedImage note = ImageIO.read (new File ("frame-1-removebg-preview.png"));
	    c.drawImage (note, 180, 220, null);

	}

	catch (IOException e)
	{
	}
	try
	{
	    BufferedImage note = ImageIO.read (new File ("frame-1-removebg-preview.png"));
	    c.drawImage (note, 430, 320, null);

	}

	catch (IOException e)
	{
	}
	try
	{
	    BufferedImage note = ImageIO.read (new File ("frame-1-removebg-preview.png"));
	    c.drawImage (note, 330, 200, null);

	}

	catch (IOException e)
	{
	}
	try
	{
	    BufferedImage note = ImageIO.read (new File ("frame-1-removebg-preview.png"));
	    c.drawImage (note, 200, 450, null);

	}

	catch (IOException e)
	{
	}
	try
	{
	    BufferedImage note = ImageIO.read (new File ("endGate.png"));
	    c.drawImage (note, 600, 450, null);

	}

	catch (IOException e)
	{
	}
    }


    int playerX = 0;
    int playerY = 250;
    public void humans ()
    {

	try
	{
	    BufferedImage human = ImageIO.read (new File ("human.png"));
	    c.drawImage (human, 0, 250, null);
	}
	catch (IOException e)
	{
	}
	try
	{
	    BufferedImage human = ImageIO.read (new File ("humanbackwards.png"));
	    c.drawImage (human, 0, 400, null);
	}
	catch (IOException e)
	{
	}

	Color grey = new Color (217, 217, 217);
	
	try
	{
	    c.setColor (Color.black);
	    c.drawString ("This is not good!", 5, 240);
	    Thread.sleep (2500);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (grey);
	    c.drawString ("This is not good!", 5, 240);
	    Thread.sleep (1000);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (Color.black);
	    c.drawString ("I am panicking!", 5, 240);
	    BufferedImage humanSurprised = ImageIO.read (new File ("humanSurprised.png"));
	    c.drawImage (humanSurprised, 0, 250, null);
	    Thread.sleep (2500);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (grey);
	    c.drawString ("I am panicking!", 5, 240);
	    Thread.sleep (1000);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (Color.black);
	    c.drawString ("Wait a minute!", 5, 240);
	    BufferedImage humanThinking = ImageIO.read (new File ("humanThinking.png"));
	    c.drawImage (humanThinking, 0, 250, null);
	    Thread.sleep (2500);
	}
	catch (Exception e)
	{
	}

	try
	{
	    c.setColor (grey);
	    c.drawString ("Wait a minute!", 5, 240);
	    Thread.sleep (1000);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (Color.black);
	    c.drawString ("I have prepared for this very scenario!", 5, 240);
	    Thread.sleep (2500);
	}
	catch (Exception e)
	{
	}
	;
	try
	{
	    c.setColor (grey);
	    c.drawString ("I have prepared for this very scenario!", 5, 240);
	    c.fillRect (0, 250, 80, 120);
	    try
	    {

		BufferedImage human = ImageIO.read (new File ("human.png"));
		c.drawImage (human, 0, 250, null);
	    }
	    catch (IOException e)
	    {
	    }
	    Thread.sleep (1000);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (Color.black);
	    c.drawString ("I have notes scattered across the room!", 5, 240);
	    Thread.sleep (2500);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (grey);
	    c.drawString ("I have notes scattered across the room!", 5, 240);
	    Thread.sleep (1000);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (Color.black);
	    c.drawString ("Each note contains some critical info", 5, 228);
	    c.drawString ("on how to stay safe during a tornado!", 5, 240);
	    Thread.sleep (2500);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (grey);
	    c.drawString ("Each note contains some critical info", 5, 228);
	    c.drawString ("on how to stay safe during a tornado!", 5, 240);
	    Thread.sleep (1000);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (Color.black);
	    c.drawString ("I just need to find them and read them!", 5, 240);
	    Thread.sleep (2500);
	}
	catch (Exception e)
	{
	}
	try
	{
	    c.setColor (grey);
	    c.drawString ("I just need to find them and read them!", 5, 240);
	    Thread.sleep (1000);
	}
	catch (Exception e)
	{
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
		for (playerY = playerY ; playerY >=187 ; playerY--)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+47, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}

		for (playerX = playerX ; playerX <=120 ; playerX++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }


		     notes();



		}
		try
		{
		    BufferedImage human = ImageIO.read (new File ("firstNote.png"));////////////////////////////////////////////////
		    c.drawImage (human, 100,0, null);
		}
		catch (IOException e)
		{
		}
	       c.getChar();
		try
		    { // imports image
			for (int i = 0 ; i <= 1 ; i++)
			{
			    BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
			    c.drawImage (menuBackground, 0, 0, null);
			}
		    }
		    catch (IOException e)
		    {
		    }
		     notes();
	       ////////////////////////////////////////////////
	   for (playerX = playerX ; playerX >=-10 ; playerX--)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		      notes();
		}

		for (playerY = playerY ; playerY >=0 ; playerY--)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		try
		{
		    BufferedImage human = ImageIO.read (new File ("EFAScale.png"));////////////////////////////////
		    c.drawImage (human, 100,0, null);
		}
		catch (IOException e)
		{
		}
	       c.getChar();
		try
		    { // imports image
			for (int i = 0 ; i <= 1 ; i++)
			{
			    BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
			    c.drawImage (menuBackground, 0, 0, null);
			}
		    }
		    catch (IOException e)
		    {
		    }
		     notes();

		/////////////////////////////////////////////////////
		for (playerX = playerX ; playerX <=215 ; playerX++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}



	      for (playerY = playerY ; playerY <=70 ; playerY++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		try
		{
		    BufferedImage human = ImageIO.read (new File ("thirdNote.png"));////////////////////////////////
		    c.drawImage (human, 100,0, null);
		}
		catch (IOException e)
		{
		}
	       c.getChar();
		try
		    { // imports image
			for (int i = 0 ; i <= 1 ; i++)
			{
			    BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
			    c.drawImage (menuBackground, 0, 0, null);
			}
		    }
		    catch (IOException e)
		    {
		    }
		     notes();

		/////////////////////////////////////////////////////
		for (playerX = playerX ; playerX <=265; playerX++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
	      for (playerY = playerY ; playerY >=-10 ; playerY--)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		try
		{
		    BufferedImage human = ImageIO.read (new File ("fourthNote.png"));////////////////////////////////
		    c.drawImage (human, 100,0, null);
		}
		catch (IOException e)
		{
		}
	       c.getChar();
		try
		    { // imports image
			for (int i = 0 ; i <= 1 ; i++)
			{
			    BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
			    c.drawImage (menuBackground, 0, 0, null);
			}
		    }
		    catch (IOException e)
		    {
		    }
		     notes();

		/////////////////////////////////////////////////////
		for (playerX = playerX ; playerX <=350; playerX++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		try
		{
		    BufferedImage human = ImageIO.read (new File ("fifthNote.png"));////////////////////////////////
		    c.drawImage (human, 100,0, null);
		}
		catch (IOException e)
		{
		}
	       c.getChar();
		try
		    { // imports image
			for (int i = 0 ; i <= 1 ; i++)
			{
			    BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
			    c.drawImage (menuBackground, 0, 0, null);
			}
		    }
		    catch (IOException e)
		    {
		    }
		     notes();

		/////////////////////////////////////////////////////
		for (playerX = playerX ; playerX >=265; playerX--)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		for (playerY = playerY ; playerY <=95; playerY++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
	     for (playerX = playerX ; playerX <=300; playerX++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		for (playerY = playerY ; playerY <=180; playerY++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		try
		{
		    BufferedImage human = ImageIO.read (new File ("sixthNote.png"));////////////////////////////////
		    c.drawImage (human, 100,0, null);
		}
		catch (IOException e)
		{
		}
	       c.getChar();
		try
		    { // imports image
			for (int i = 0 ; i <= 1 ; i++)
			{
			    BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
			    c.drawImage (menuBackground, 0, 0, null);
			}
		    }
		    catch (IOException e)
		    {
		    }
		     notes();

		/////////////////////////////////////////////////////
		for (playerX = playerX ; playerX >=220; playerX--)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}

		for (playerY = playerY ; playerY <=225; playerY++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		try
		{
		    BufferedImage human = ImageIO.read (new File ("seventhNote.png"));////////////////////////////////
		    c.drawImage (human, 100,0, null);
		}
		catch (IOException e)
		{
		}
	       c.getChar();
		try
		    { // imports image
			for (int i = 0 ; i <= 1 ; i++)
			{
			    BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
			    c.drawImage (menuBackground, 0, 0, null);
			}
		    }
		    catch (IOException e)
		    {
		    }
		     notes();

		/////////////////////////////////////////////////////
		for (playerY = playerY ; playerY >=180; playerY--)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		for (playerX = playerX ; playerX <=300; playerX++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
	      for (playerY = playerY ; playerY <=320; playerY++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		for (playerX = playerX ; playerX >=205; playerX--)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		for (playerY = playerY ; playerY <=420; playerY++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		try
		{
		    BufferedImage human = ImageIO.read (new File ("eighthNote.png"));////////////////////////////////
		    c.drawImage (human, 100,0, null);
		}
		catch (IOException e)
		{
		}
	       c.getChar();
		try
		    { // imports image
			for (int i = 0 ; i <= 1 ; i++)
			{
			    BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
			    c.drawImage (menuBackground, 0, 0, null);
			}
		    }
		    catch (IOException e)
		    {
		    }


		/////////////////////////////////////////////////////
	      for (playerX = playerX ; playerX >=180; playerX--)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		for (playerX = playerX ; playerX <=205; playerX++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		for (playerY = playerY ; playerY >=320; playerY--)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}

	     for (playerX = playerX ; playerX <=430; playerX++)
		{
		    try
		    {
			c.setColor (grey);
			c.fillRect (playerX+46, playerY+10, 28, 44); ///(+47, +10, 25,44)
			try
			{
			    BufferedImage human = ImageIO.read (new File ("human.png"));
			    c.drawImage (human, playerX, playerY, null);
			}

			catch (IOException e)
			{
			}

			Thread.sleep (25);
		    }
		    catch (Exception e)
		    {
		    }
		    notes();
		}
		try
		{
		    BufferedImage human = ImageIO.read (new File ("ninthNote.png"));////////////////////////////////
		    c.drawImage (human, 100,0, null);
		}
		catch (IOException e)
		{
		}
	       c.getChar();
		try
		    { // imports image
			for (int i = 0 ; i <= 1 ; i++)
			{
			    BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
			    c.drawImage (menuBackground, 0, 0, null);
			}
		    }
		    catch (IOException e)
		    {
		    }

	  
	/////////////////////////////////////////////////////
	for (playerY = playerY ; playerY <= 365 ; playerY++)
	{
	    try
	    {
		c.setColor (grey);
		c.fillRect (playerX + 46, playerY + 10, 28, 44); ///(+47, +10, 25,44)
		try
		{
		    BufferedImage human = ImageIO.read (new File ("human.png"));
		    c.drawImage (human, playerX, playerY, null);
		}

		catch (IOException e)
		{
		}

		Thread.sleep (25);
	    }
	    catch (Exception e)
	    {
	    }

	    notes ();
	}


	for (playerX = playerX ; playerX <= 550 ; playerX++)
	{
	    try
	    {
		c.setColor (grey);
		c.fillRect (playerX + 46, playerY + 10, 28, 44); ///(+47, +10, 25,44)
		try
		{
		    BufferedImage human = ImageIO.read (new File ("human.png"));
		    c.drawImage (human, playerX, playerY, null);
		}

		catch (IOException e)
		{
		}

		Thread.sleep (25);
	    }
	    catch (Exception e)
	    {
	    }
	     notes ();
	}
       


    


    for (playerY = playerY ; playerY <= 420 ; playerY++)
    {
	try
	{
	    c.setColor (grey);
	    c.fillRect (playerX + 46, playerY + 10, 28, 44); ///(+47, +10, 25,44)
	    try
	    {
		BufferedImage human = ImageIO.read (new File ("human.png"));
		c.drawImage (human, playerX, playerY, null);
	    }

	    catch (IOException e)
	    {
	    }

	    Thread.sleep (25);
	}
	catch (Exception e)
	{
	}

	notes ();
    }


     try
	{
	    BufferedImage human = ImageIO.read (new File ("tenthNote.png")); ////////////////////////////////
	    c.drawImage (human, 100, 0, null);
	}
	catch (IOException e)
	{
	}
	c.getChar ();
	try
	{ // imports image
	    for (int i = 0 ; i <= 1 ; i++)
	    {
		BufferedImage menuBackground = ImageIO.read (new File ("0.png"));
		c.drawImage (menuBackground, 0, 0, null);
	    }
	}
	catch (IOException e)
	{
	}
    
    
    
    
    
    //end of code
}









    public void run ()
    {
	{
	    background ();
	    humans ();
	}
    }
}
