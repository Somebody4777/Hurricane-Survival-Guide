import java.awt.*;
import hsa.Console;

///NOTE that because the program does not require two objects from different classes
///running at once, there was no need for .run().
public class livingRoomMaze extends Thread{
Console c; // c is variable representation of Console
   public livingRoomMaze ()
    {
	c = new Console ("Fishing in a Storm");
	
    }
public void mazeLevel(){


maze2 p2 = new maze2 (c);
p2.start();


}
public static void main (String [] args)
{
livingRoomMaze z = new livingRoomMaze();
z.mazeLevel();
}
}
